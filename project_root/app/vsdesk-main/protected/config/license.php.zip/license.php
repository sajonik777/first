<?php
// Licensing constants for paid clients
define('redaction', 'CORP');
define('licensor', 'ООО "ЮНИВЕФ"');
define('serial', '8RYL-QBCK-440A-ZIU0-NU76B');
define('update_login', 'univef');
define('update_password', 'HDGz9K1emV2d27y8');
define('support_date', '27.01.2024');
define('license_date', '');